<p align="center">
  <h1 align="center">🎵 Rishav Music Bot</h1>
  <p align="center">A powerful Telegram Music Bot — Rebranded & Styled by Rishav</p>
</p>

<p align="center">
  <img src="https://img.shields.io/badge/Rishav%20Music-Bot-blue?style=for-the-badge" alt="Rishav Music">
  <img src="https://img.shields.io/badge/Python-3.9+-green?style=for-the-badge&logo=python" alt="Python">
  <img src="https://img.shields.io/badge/Pyrogram-2.0-orange?style=for-the-badge" alt="Pyrogram">
</p>

---

## 🎶 Features

- 🎵 Stream music from **YouTube, Spotify, Apple Music, SoundCloud, Resso**
- 📺 **Video streaming** support in voice chats
- 🔁 Loop, shuffle, seek, skip, pause, resume
- 📋 Queue management
- 💾 Playlist save & load
- 🎤 Lyrics search
- ⚙️ Full group settings panel
- 🔐 Admin & sudo user management
- 📢 Broadcast to all chats
- 🌍 Multi-language support

---

## ⚙️ Setup & Deployment

### Required Variables

| Variable | Description |
|----------|-------------|
| `API_ID` | Get from [my.telegram.org](https://my.telegram.org) |
| `API_HASH` | Get from [my.telegram.org](https://my.telegram.org) |
| `BOT_TOKEN` | Get from [@BotFather](https://t.me/BotFather) |
| `MONGO_DB_URI` | MongoDB connection string |
| `OWNER_ID` | Your Telegram User ID |

### Optional Variables

| Variable | Description |
|----------|-------------|
| `SUPPORT_CHANNEL` | Your support channel link |
| `SUPPORT_GROUP` | Your support group link |
| `SPOTIFY_CLIENT_ID` | Spotify API Client ID |
| `SPOTIFY_CLIENT_SECRET` | Spotify API Secret |

---

## 🚀 Deploy

### On VPS / Local
```bash
git clone https://github.com/YourRepo/RishavMusicBot
cd RishavMusicBot
pip install -r requirements.txt
cp sample.env .env
# Fill in your .env variables
bash start
```

### On Heroku
Click the button below (set up your own app.json first):
```
heroku create
heroku config:set API_ID=xxx ...
git push heroku master
```

---

## 📝 Commands

| Command | Description |
|---------|-------------|
| `/play` | Play a song |
| `/pause` | Pause music |
| `/resume` | Resume music |
| `/skip` | Skip track |
| `/stop` | Stop music |
| `/queue` | View queue |
| `/shuffle` | Shuffle queue |
| `/loop` | Toggle loop |
| `/lyrics` | Get lyrics |
| `/ping` | Check bot status |
| `/settings` | Group settings |
| `/help` | Help menu |

---

## 🙏 Credits

- Originally based on [YukkiMusicBot](https://github.com/TeamYukki/YukkiMusicBot)
- Rebranded & restyled by **Rishav**

---

<p align="center">Made with ❤️ by Rishav</p>
